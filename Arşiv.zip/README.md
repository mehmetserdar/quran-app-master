# quran-app

Initial release
webapp is built with html,css and js. quran api was used.

[![Netlify Status](https://api.netlify.com/api/v1/badges/39a90d35-b8b0-4ffb-b474-3a01a9afb51b/deploy-status)](https://app.netlify.com/sites/kuranikerim/deploys)

[Get it on Google Play](https://play.google.com/store/apps/details?id=com.mobuyg.kuran)
# quran-app-master
